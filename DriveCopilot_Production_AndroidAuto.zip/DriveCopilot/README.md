# Drive Copilot — production-oriented Android Auto + OBD-II build

This project contains the V1–V4 OBD-II vehicle intelligence MVP plus a dedicated Android Auto car UI.

## What is included

- **V1 — OBD telemetry:** Bluetooth Classic ELM327 connection and standard OBD-II PIDs.
- **V2 — Vehicle health:** conservative health score and diagnostic alerts.
- **V3 — Driving Copilot:** minimal, distraction-aware car-screen status and alerts.
- **V4 — Predictive maintenance foundation:** persistent telemetry state and anomaly-oriented health architecture. This is intentionally not presented as a certified failure predictor.
- **Phone UI:** polished dashboard with connection state, live telemetry, health, alerts and Android Auto status.
- **Android Auto UI:** dedicated templated interface using Android for Cars App Library 1.7.0. The car surface intentionally contains only essential vehicle status and health information.

## Android Auto / production notes

Android Auto templated apps must declare the `template` capability and a supported Car App category. This project uses the **IoT** category because the app's core car surface exposes telemetry from a connected physical sensor device (the OBD-II adapter). Google Play eligibility is ultimately determined by Google's category and quality review; no source-code change can guarantee approval.

The service uses Google's recommended host validation pattern: unknown hosts are accepted only in debug builds; release builds use the library's sample host allowlist. Before publishing, verify the allowlist and current Play requirements against the release environment.

The project uses Car App Library 1.7.0. Test the car surface with the Android Auto Desktop Head Unit (DHU) and the Android Automotive OS emulator where applicable. Do not test while actively driving; use a parked vehicle, simulator, or a second person for observation.

## Important technical limitation

OBD-II coverage varies by vehicle and adapter. Unsupported PIDs are treated as unavailable rather than as faults. Predictive maintenance should be framed as anomaly detection / maintenance guidance until you have enough vehicle-specific historical data and validation to support stronger claims.
