package com.example.drivecopilot.state

import android.content.Context
import androidx.core.content.edit
import org.json.JSONArray

/** Small process-safe persistence layer shared by the phone UI and car UI. */
object DriveStateStore {
    private const val PREFS = "drive_state"
    private const val KEY_CONNECTED = "connected"
    private const val KEY_DEVICE = "device"
    private const val KEY_SPEED = "speed"
    private const val KEY_RPM = "rpm"
    private const val KEY_COOLANT = "coolant"
    private const val KEY_LOAD = "load"
    private const val KEY_THROTTLE = "throttle"
    private const val KEY_DTC = "dtc"
    private const val KEY_HEALTH = "health"
    private const val KEY_ALERT = "alert"
    private const val KEY_LAST_UPDATED = "last_updated"

    data class Snapshot(
        val connected: Boolean,
        val deviceName: String,
        val speedKph: Double?,
        val rpm: Double?,
        val coolantC: Double?,
        val engineLoadPct: Double?,
        val throttlePct: Double?,
        val dtcCount: Int,
        val health: Int,
        val alert: String,
        val lastUpdated: Long
    )

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun save(context: Context, snapshot: Snapshot) {
        prefs(context).edit {
            putBoolean(KEY_CONNECTED, snapshot.connected)
            putString(KEY_DEVICE, snapshot.deviceName)
            putFloat(KEY_SPEED, snapshot.speedKph?.toFloat() ?: Float.NaN)
            putFloat(KEY_RPM, snapshot.rpm?.toFloat() ?: Float.NaN)
            putFloat(KEY_COOLANT, snapshot.coolantC?.toFloat() ?: Float.NaN)
            putFloat(KEY_LOAD, snapshot.engineLoadPct?.toFloat() ?: Float.NaN)
            putFloat(KEY_THROTTLE, snapshot.throttlePct?.toFloat() ?: Float.NaN)
            putInt(KEY_DTC, snapshot.dtcCount)
            putInt(KEY_HEALTH, snapshot.health)
            putString(KEY_ALERT, snapshot.alert)
            putLong(KEY_LAST_UPDATED, snapshot.lastUpdated)
        }
    }

    fun clear(context: Context) {
        prefs(context).edit { clear() }
    }

    fun read(context: Context): Snapshot {
        val p = prefs(context)
        fun number(key: String): Double? = p.getFloat(key, Float.NaN).takeUnless { it.isNaN() }?.toDouble()
        return Snapshot(
            connected = p.getBoolean(KEY_CONNECTED, false),
            deviceName = p.getString(KEY_DEVICE, "") ?: "",
            speedKph = number(KEY_SPEED),
            rpm = number(KEY_RPM),
            coolantC = number(KEY_COOLANT),
            engineLoadPct = number(KEY_LOAD),
            throttlePct = number(KEY_THROTTLE),
            dtcCount = p.getInt(KEY_DTC, 0),
            health = p.getInt(KEY_HEALTH, 100),
            alert = p.getString(KEY_ALERT, "No active alerts") ?: "No active alerts",
            lastUpdated = p.getLong(KEY_LAST_UPDATED, 0L)
        )
    }
}
