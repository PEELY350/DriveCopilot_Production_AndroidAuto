package com.example.drivecopilot.vehicle

import android.content.Context
import com.example.drivecopilot.obd.VehicleSample
import kotlin.math.max

class VehicleAnalyzer(private val context: Context) {
    private val samples = ArrayDeque<VehicleSample>()
    private var lastAlert = "Alerts: none"

    fun accept(s: VehicleSample) {
        if (samples.size >= 120) samples.removeFirst()
        samples.addLast(s)

        lastAlert = when {
            s.coolantC != null && s.coolantC >= 110 ->
                "🔴 Engine temperature is unusually high. Stop safely and have the vehicle checked."
            s.coolantC != null && s.coolantC >= 105 ->
                "🟠 Coolant temperature is elevated. Monitor it and arrange an inspection if it persists."
            s.dtcCount > 0 ->
                "🟡 Diagnostic trouble code(s) detected. Read the codes before deciding whether service is needed."
            else -> "Alerts: none"
        }
    }

    fun healthScore(): Int {
        if (samples.isEmpty()) return 0
        val latest = samples.last()
        var score = 100

        if (latest.dtcCount > 0) score -= minOf(35, latest.dtcCount * 10)
        if (latest.coolantC != null) {
            score -= when {
                latest.coolantC >= 110 -> 35
                latest.coolantC >= 105 -> 20
                latest.coolantC >= 100 -> 8
                else -> 0
            }
        }

        // Simple anomaly component: compare latest coolant to recent average.
        val temps = samples.mapNotNull { it.coolantC }
        if (temps.size >= 10) {
            val avg = temps.takeLast(10).average()
            if (latest.coolantC != null && latest.coolantC > avg + 8) score -= 10
        }

        return score.coerceIn(0, 100)
    }

    fun currentAlert(): String = lastAlert
}
