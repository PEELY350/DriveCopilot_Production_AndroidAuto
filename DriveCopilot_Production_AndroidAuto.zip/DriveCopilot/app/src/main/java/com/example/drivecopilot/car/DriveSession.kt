package com.example.drivecopilot.car

import android.content.Intent
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.ListTemplate
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import com.example.drivecopilot.state.DriveStateStore

class DriveSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen = DriveHomeScreen(carContext)
}

private class DriveHomeScreen(carContext: CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        val s = DriveStateStore.read(carContext)
        val status = if (s.connected) "OBD connected • ${s.deviceName}" else "OBD adapter not connected"
        val health = when {
            s.health >= 85 -> "Healthy • ${s.health}/100"
            s.health >= 60 -> "Check soon • ${s.health}/100"
            else -> "Attention • ${s.health}/100"
        }

        val pane = Pane.Builder()
            .addRow(Row.Builder().setTitle("Vehicle status").addText(status).build())
            .addRow(Row.Builder().setTitle("Vehicle health").addText(health).build())
            .addRow(Row.Builder().setTitle("Driving alert").addText(s.alert).build())
            .addRow(
                Row.Builder()
                    .setTitle("Live data")
                    .addText(
                        "Speed ${s.speedKph?.let { "%.0f km/h".format(it) } ?: "—"}  •  " +
                            "RPM ${s.rpm?.let { "%.0f".format(it) } ?: "—"}  •  " +
                            "Coolant ${s.coolantC?.let { "%.0f°C".format(it) } ?: "—"}"
                    )
                    .build()
            )
            .addAction(
                Action.Builder()
                    .setTitle("Health details")
                    .setOnClickListener { screenManager.push(HealthScreen(carContext)) }
                    .build()
            )
            .addAction(
                Action.Builder()
                    .setTitle("Refresh")
                    .setOnClickListener {
                        invalidate()
                        CarToast.makeText(carContext, "Vehicle data refreshed", CarToast.LENGTH_SHORT).show()
                    }
                    .build()
            )
            .build()

        return PaneTemplate.Builder(pane)
            .setTitle("Drive Copilot")
            .setHeaderAction(Action.APP_ICON)
            .build()
    }
}

private class HealthScreen(carContext: CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template {
        val s = DriveStateStore.read(carContext)
        val items = ItemList.Builder()
            .addItem(Row.Builder().setTitle("Health score").addText("${s.health}/100").build())
            .addItem(Row.Builder().setTitle("Diagnostic codes").addText(if (s.dtcCount == 0) "None detected" else "${s.dtcCount} detected").build())
            .addItem(Row.Builder().setTitle("Coolant").addText(s.coolantC?.let { "%.0f°C".format(it) } ?: "Unavailable").build())
            .addItem(Row.Builder().setTitle("Engine load").addText(s.engineLoadPct?.let { "%.0f%%".format(it) } ?: "Unavailable").build())
            .addItem(Row.Builder().setTitle("Throttle").addText(s.throttlePct?.let { "%.0f%%".format(it) } ?: "Unavailable").build())
            .build()

        return ListTemplate.Builder()
            .setSingleList(items)
            .setTitle("Vehicle health")
            .setHeaderAction(Action.BACK)
            .build()
    }
}
