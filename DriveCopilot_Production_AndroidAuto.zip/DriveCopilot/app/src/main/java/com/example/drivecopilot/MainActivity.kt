package com.example.drivecopilot

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.drivecopilot.databinding.ActivityMainBinding
import com.example.drivecopilot.obd.Elm327Client
import com.example.drivecopilot.obd.ObdRepository
import com.example.drivecopilot.state.DriveStateStore
import com.example.drivecopilot.vehicle.VehicleAnalyzer
import kotlinx.coroutines.*
import android.content.pm.PackageManager

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var analyzer: VehicleAnalyzer
    private var client: Elm327Client? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.values.all { it }) connect() else setDisconnected("Bluetooth permission is required.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        analyzer = VehicleAnalyzer(this)
        render(DriveStateStore.read(this))
        binding.connectButton.setOnClickListener { ensurePermissionsAndConnect() }
    }

    private fun ensurePermissionsAndConnect() {
        if (Build.VERSION.SDK_INT >= 31) {
            val missing = arrayOf(Manifest.permission.BLUETOOTH_CONNECT).filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray()) else connect()
        } else connect()
    }

    private fun connect() {
        scope.launch {
            try {
                binding.connectButton.isEnabled = false
                binding.status.text = "Looking for a paired OBD-II adapter…"
                val adapter = BluetoothAdapter.getDefaultAdapter()
                    ?: error("This phone does not provide Bluetooth.")

                val device = withContext(Dispatchers.IO) {
                    adapter.bondedDevices.firstOrNull {
                        val n = it.name.orEmpty()
                        n.contains("OBD", true) || n.contains("ELM", true)
                    }
                } ?: error("No paired OBD/ELM327 device found. Pair it in Android Settings first.")

                binding.status.text = "Connecting to ${device.name}…"
                val obd = Elm327Client(device)
                client = obd
                withContext(Dispatchers.IO) { obd.connect() }
                binding.status.text = "Connected to ${device.name}"

                val repo = ObdRepository(obd)
                while (isActive) {
                    val sample = withContext(Dispatchers.IO) { repo.readSample() }
                    analyzer.accept(sample)
                    val health = analyzer.healthScore()
                    val alert = analyzer.currentAlert()
                    val snapshot = DriveStateStore.Snapshot(
                        connected = true,
                        deviceName = device.name.orEmpty(),
                        speedKph = sample.speedKph,
                        rpm = sample.rpm,
                        coolantC = sample.coolantC,
                        engineLoadPct = sample.engineLoadPct,
                        throttlePct = sample.throttlePct,
                        dtcCount = sample.dtcCount,
                        health = health,
                        alert = alert,
                        lastUpdated = System.currentTimeMillis()
                    )
                    DriveStateStore.save(this@MainActivity, snapshot)
                    render(snapshot)
                    delay(1500)
                }
            } catch (t: Throwable) {
                setDisconnected(t.message ?: "Connection failed.")
            } finally {
                withContext(NonCancellable + Dispatchers.IO) { client?.close() }
                client = null
                binding.connectButton.isEnabled = true
            }
        }
    }

    private fun render(s: DriveStateStore.Snapshot) {
        binding.connectionBadge.text = if (s.connected) "CONNECTED" else "OFFLINE"
        binding.status.text = if (s.connected) "Live vehicle telemetry • ${s.deviceName}" else binding.status.text
        binding.health.text = "${s.health}/100"
        binding.alertCount.text = if (s.alert == "No active alerts") "0" else "1"
        binding.telemetry.text = listOf(
            "Speed     ${s.speedKph?.let { "%.0f km/h".format(it) } ?: "—"}",
            "RPM       ${s.rpm?.let { "%.0f".format(it) } ?: "—"}",
            "Coolant   ${s.coolantC?.let { "%.0f °C".format(it) } ?: "—"}",
            "Load      ${s.engineLoadPct?.let { "%.0f%%".format(it) } ?: "—"}",
            "Throttle  ${s.throttlePct?.let { "%.0f%%".format(it) } ?: "—"}",
            "DTCs      ${s.dtcCount}"
        ).joinToString("\n")
        binding.alerts.text = s.alert
    }

    private fun setDisconnected(message: String) {
        val current = DriveStateStore.read(this).copy(connected = false, alert = "No active alerts")
        DriveStateStore.save(this, current)
        binding.connectionBadge.text = "OFFLINE"
        binding.status.text = message
        binding.connectButton.isEnabled = true
        render(current)
    }

    override fun onDestroy() {
        scope.cancel()
        client?.close()
        super.onDestroy()
    }
}
