package com.example.drivecopilot.obd

import kotlin.math.roundToInt

data class VehicleSample(
    val timestamp: Long = System.currentTimeMillis(),
    val speedKph: Double?,
    val rpm: Double?,
    val coolantC: Double?,
    val engineLoadPct: Double?,
    val throttlePct: Double?,
    val dtcCount: Int
)

class ObdRepository(private val client: Elm327Client) {

    suspend fun readSample(): VehicleSample {
        val speed = parseSingleByte(client.pid("01", "0D"))?.toDouble()
        val rpmRaw = parseTwoBytes(client.pid("01", "0C"))
        val rpm = rpmRaw?.let { it / 4.0 }
        val coolant = parseSingleByte(client.pid("01", "05"))?.let { it - 40.0 }
        val load = parseSingleByte(client.pid("01", "04"))?.let { it * 100.0 / 255.0 }
        val throttle = parseSingleByte(client.pid("01", "11"))?.let { it * 100.0 / 255.0 }
        val dtcs = readDtcCount()

        return VehicleSample(
            speedKph = speed,
            rpm = rpm,
            coolantC = coolant,
            engineLoadPct = load,
            throttlePct = throttle,
            dtcCount = dtcs
        )
    }

    private suspend fun readDtcCount(): Int {
        val response = client.pid("03", "")
        // Conservative parser: count valid 4-hex-character DTC frames.
        val cleaned = response.replace(Regex("[^0-9A-Fa-f]"), "")
        if (cleaned.length < 4) return 0
        return cleaned.chunked(4).count { it.length == 4 && it != "4300" }
    }

    private fun bytes(response: String): List<Int> =
        response.split(Regex("\\s+"))
            .mapNotNull { token ->
                token.takeIf { it.matches(Regex("[0-9A-Fa-f]{2}")) }?.toInt(16)
            }

    private fun parseSingleByte(response: String): Int? {
        val b = bytes(response)
        // Typical response: 41 PID DATA
        return b.dropWhile { it != 0x41 }.drop(2).firstOrNull()
    }

    private fun parseTwoBytes(response: String): Int? {
        val b = bytes(response)
        val data = b.dropWhile { it != 0x41 }.drop(2)
        return if (data.size >= 2) (data[0] shl 8) or data[1] else null
    }
}
