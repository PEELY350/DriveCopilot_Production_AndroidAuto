package com.example.drivecopilot.obd

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.OutputStream
import java.util.UUID

class Elm327Client(private val device: BluetoothDevice) {
    private var socket: BluetoothSocket? = null
    private var input: BufferedInputStream? = null
    private var output: OutputStream? = null

    companion object {
        // Standard Bluetooth Classic SPP UUID used by many ELM327 adapters.
        private val SPP_UUID: UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    suspend fun connect() = withContext(Dispatchers.IO) {
        socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
        socket!!.connect()
        input = BufferedInputStream(socket!!.inputStream)
        output = socket!!.outputStream

        command("ATZ")
        command("ATE0")
        command("ATL0")
        command("ATS0")
        command("ATH0")
        command("ATSP0")
    }

    suspend fun command(cmd: String): String = withContext(Dispatchers.IO) {
        val out = output ?: error("Not connected")
        val inp = input ?: error("Not connected")
        out.write((cmd.trim() + "\r").toByteArray())
        out.flush()

        val buffer = ByteArray(4096)
        val sb = StringBuilder()
        while (true) {
            val n = inp.read(buffer)
            if (n <= 0) break
            sb.append(String(buffer, 0, n, Charsets.US_ASCII))
            if (sb.contains(">")) break
        }
        sb.toString().replace(">", "").trim()
    }

    suspend fun pid(mode: String, pid: String): String =
        command("$mode $pid")

    suspend fun close() = withContext(Dispatchers.IO) {
        socket?.close()
        socket = null
    }
}
